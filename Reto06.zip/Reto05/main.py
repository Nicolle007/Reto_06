import math
from Figuras.Shapes.punto import Punto
from Figuras.Shapes.linea import Linea
from Figuras.Shapes.Triangulo import Triangulo
from Figuras.Shapes.Rectangulo import Rectangulo
from Figuras.Shapes.Triangulo import Isosceles
from Figuras.Shapes.Triangulo import Equilatero
from Figuras.Shapes.Triangulo import Escaleno
from Figuras.Shapes.Triangulo import Tri_Rectangulo
from Figuras.Shapes.Rectangulo import Cuadrado

def main():

    p1 = Punto([0, 0])
    p2 = Punto([4, 0])
    p3 = Punto([4, 3])
    p4 = Punto([0, 3])

    p5 = Punto([0, 0])
    p6 = Punto([3, 0])
    p7 = Punto([1.5, 2.598])  

    p8 = Punto([0, 0])
    p9 = Punto([5, 0])
    p10 = Punto([2, 4])


    def calcular_longitud(p_inicio, p_final):
        return math.sqrt((p_final.x - p_inicio.x) ** 2 + (p_final.y - p_inicio.y) ** 2)

    l1 = Linea(p1, p2, calcular_longitud(p1, p2))
    l2 = Linea(p2, p3, calcular_longitud(p2, p3))
    l3 = Linea(p3, p4, calcular_longitud(p3, p4))
    l4 = Linea(p4, p1, calcular_longitud(p4, p1))

    rect_bordes = [l1, l2, l3, l4]
    rect_angulos = [90, 90, 90, 90]
    rect_vertices = [p1, p2, p3, p4]

    le = 3
    pA = Punto([0,0])
    pB = Punto([le,0])
    pC = Punto([le/2, le * math.sqrt(3)/2])

    lA = Linea(pA, pB, calcular_longitud(pA, pB))
    lB = Linea(pB, pC, calcular_longitud(pB, pC))
    lC = Linea(pC, pA, calcular_longitud(pC, pA))

    equil_bordes = [lA, lB, lC]
    equil_angulos = [60, 60, 60]
    equil_vertices = [pA, pB, pC]

    pI1 = Punto([0,0])
    pI2 = Punto([6,0])
    pI3 = Punto([3,4]) 

    lI1 = Linea(pI1, pI2, calcular_longitud(pI1, pI2))
    lI2 = Linea(pI2, pI3, calcular_longitud(pI2, pI3))
    lI3 = Linea(pI3, pI1, calcular_longitud(pI3, pI1))

    isos_bordes = [lI1, lI2, lI3]
    isos_angulos = [calcular_longitud(pI3, pI1), calcular_longitud(pI2, pI3), calcular_longitud(pI1, pI2)] 
    isos_vertices = [pI1, pI2, pI3]


    pE1 = Punto([0,0])
    pE2 = Punto([4,0])
    pE3 = Punto([4,3])

    lE1 = Linea(pE1, pE2, calcular_longitud(pE1, pE2))
    lE2 = Linea(pE2, pE3, calcular_longitud(pE2, pE3))
    lE3 = Linea(pE3, pE1, calcular_longitud(pE3, pE1))

    esca_bordes = [lE1, lE2, lE3]
    esca_angulos = [60, 90, 30]  
    esca_vertices = [pE1, pE2, pE3]

    triR_bordes = esca_bordes
    triR_angulos = [90, 53.13, 36.87]
    triR_vertices = esca_vertices

    cuadrado = Cuadrado(vertices=rect_vertices, bordes=rect_bordes, angulos_interiores=rect_angulos)
    print(cuadrado.compute_area())

    equilatero = Equilatero(vertices=equil_vertices, bordes=equil_bordes, angulos_interiores=equil_angulos)
    print(equilatero.compute_area())

    isosceles = Isosceles(vertices=isos_vertices, bordes=isos_bordes, angulos_interiores=[70, 40, 70]) 
    print( isosceles.compute_area())

    escaleno = Escaleno(vertices=esca_vertices, bordes=esca_bordes, angulos_interiores=esca_angulos)
    print( escaleno.compute_area())

    tri_rectangulo = Tri_Rectangulo(vertices=triR_vertices, bordes=triR_bordes, angulos_interiores=triR_angulos)
    print( tri_rectangulo.compute_area())
    
if __name__ == "__main__":
  main()  