class GeometriaError(Exception):#Esta va a ser la clase padre de la que hereden las demas
    pass

class DimensionError(GeometriaError):
    def __init__(self, message="Número incorrecto de dimensiones o elementos para la figura.", esperado=None, obtenido=None):
        super().__init__(message)
        self.esperado = esperado
        self.obtenido = obtenido
        
#Esta clase nos permite indicar al usuario que faltan o hay demas elementos de los esperados:
#Ej: a la hora de definir una linea requerimos 3 atributos para realizarlo

class DatosInvalidosError(GeometriaError):
    def __init__(self, message="Datos de entrada inválidos para la figura.", datos=None):
        super().__init__(message)
        self.datos = datos
        
#Esta clase nos permite indicar al usuario los elementos no son los esperados:
#Ej: a la hora de definir una linea dos de sus atributos deben ser nescesariamente puntos para que funcione

