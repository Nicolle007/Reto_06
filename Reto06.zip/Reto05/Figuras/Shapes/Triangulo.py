import math
from .shape import Shape
from .punto import Punto
from .linea import Linea
class Triangulo(Shape):
    def __init__(self, vertices, bordes, angulos_interiores):
        super().__init__(vertices, bordes, angulos_interiores)

    def compute_area(self):
        raise NotImplementedError("Las subclases deben implementar el método")
    
class Isosceles(Triangulo):
    def __init__(self, vertices, bordes, angulos_interiores):
        super().__init__(vertices, bordes, angulos_interiores)

    def compute_area(self):
        todos_bordes = [i.longitud for i in self._bordes]

        repetido = []
        unico = []
        vistos = set()

        for x in todos_bordes:
            if todos_bordes.count(x) > 1 and x not in vistos:
                repetido.append(x)
                vistos.add(x)
            elif todos_bordes.count(x) == 1:
                unico.append(x)

        cateto = int(unico[0]) / 2
        hipotenusa = int(repetido[0])
        altura = math.sqrt((hipotenusa ** 2) - (cateto ** 2))
        Area = ((cateto * 2) * altura) / 2
        return Area


class Equilatero(Triangulo):
    def __init__(self, vertices, bordes, angulos_interiores):
        super().__init__(vertices, bordes, angulos_interiores)

    def compute_area(self):
        cateto = int(self._bordes[0].longitud) / 2
        hipotenusa = int(self._bordes[0].longitud)
        altura = math.sqrt((hipotenusa ** 2) - (cateto ** 2))
        Area = ((cateto * 2) * altura) / 2
        return Area


class Escaleno(Triangulo):
    def __init__(self, vertices, bordes, angulos_interiores):
        super().__init__(vertices, bordes, angulos_interiores)

    def compute_area(self):
        borde_1 = int(self._bordes[0].longitud)
        borde_2 = int(self._bordes[1].longitud)
        borde_3 = int(self._bordes[2].longitud)
        semi_p = (borde_1 + borde_2 + borde_3) / 2
        Area = math.sqrt(semi_p * (semi_p - borde_1) * (semi_p - borde_2) * (semi_p - borde_3))
        return Area


class Tri_Rectangulo(Triangulo):
    def __init__(self, vertices, bordes, angulos_interiores):
        super().__init__(vertices, bordes, angulos_interiores)

    def compute_area(self):
        todos_bordes = [i.longitud for i in self._bordes]
        hipotenusa = max(todos_bordes)
        catetos = [l for l in todos_bordes if l != hipotenusa]
        if len(catetos) != 2:
            raise ValueError("No se encontraron exactamente dos catetos.")
        cateto_1 = catetos[0]
        cateto_2 = catetos[1]
        return (cateto_1 * cateto_2) / 2