from .punto import Punto
from .errores import DatosInvalidosError
class Linea:
    def __init__(self, punto_inicial=None, punto_final=None, longitud=0.0):
        try:
            self.longitud = float(longitud) # Intentar convertir a float para ver si es un valor numerico
        except (ValueError, TypeError) as e:
            raise DatosInvalidosError(f"La 'longitud' proporcionada para la Linea no es un valor numérico válido. Error: {e}",
                                      datos=longitud) from e
        self.punto_inicial = punto_inicial
        self.punto_final = punto_final
        self.longitud = longitud